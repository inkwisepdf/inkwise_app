package com.example.inkwise_pdf

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
